import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {

        FileReader fileReader = new FileReader();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file directory: ");
        String path = scanner.nextLine();

        Record[] insertionRecords = fileReader.readFile(path);
        Record[] selectionRecords = fileReader.readFile(path);
        Record[] mergeRecords = fileReader.readFile(path);
        Record[] quickRecords = fileReader.readFile(path);

        SortingAlgorithms sortingAlgo = new SortingAlgorithms();
        Counter counter = new Counter();
        int choice = 0;

        while (choice != 5) { // Menu
            System.out.println("Menu:");
            System.out.println("1. Insertion Sort");
            System.out.println("2. Selection Sort");
            System.out.println("3. Merge Sort");
            System.out.println("4. Quick Sort");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            System.out.println();


            switch (choice) {
                case 1: { // For insertion sort
                    if (insertionRecords != null) {
                        Record[] records = insertionRecords.clone();
                        long startTime = System.currentTimeMillis(); // store the current time (Before Sorting)
                        sortingAlgo.insertionSort(records, records.length);
                        long endTime = System.currentTimeMillis(); // store the current time (After Sorting)
                        long executionTime = endTime - startTime;
                        System.out.println("Insertion Sort:");
                        printRecords(records);
                        System.out.println();
                        System.out.println("Execution Time: " +executionTime+ " millisecond/s");
                        System.out.println();
                        Record[] recordsCounter = insertionRecords.clone();
                        long insCount = counter.insertionSort(recordsCounter, recordsCounter.length);
                        System.out.println("Empirical Frequency Count: " +insCount);
                        System.out.println();
                        boolean isSorted = verifySorting(records);
                        if(isSorted)
                        {
                            System.out.println("Sorting Successful! Results: " + true);

                        }
                        else
                        {
                            System.out.println("Sorting unsuccessful... Results: " + false);
                        }
                        System.out.println();
                        System.out.println();


                    }
                    break;
                }
                case 2: { // For Selection Sort
                    if (selectionRecords != null) {
                        Record[] records = selectionRecords.clone();
                        long startTime = System.currentTimeMillis(); // store the current time (Before Sorting)
                        sortingAlgo.selectionSort(records, records.length);
                        long endTime = System.currentTimeMillis(); // store the current time (After Sorting)
                        long executionTime = endTime - startTime;
                        System.out.println("Selection Sort:");
                        printRecords(records);
                        System.out.println();
                        System.out.println("Execution Time: " +executionTime+ " millisecond/s");
                        System.out.println();
                        Record[] recordsCounter = selectionRecords.clone();
                        long selCount = counter.selectionSort(recordsCounter, recordsCounter.length);
                        System.out.println("Empirical Frequency Count: " +selCount);
                        System.out.println();
                        boolean isSorted = verifySorting(records);
                        if(isSorted)
                        {
                            System.out.println("Sorting Successful! Results: " + true);
                        }
                        else
                        {
                            System.out.println("Sorting unsuccessful... Results: " + false);
                        }
                        System.out.println();
                        System.out.println();
                    }
                    break;
                }
                case 3: { // For merge sort
                    if (mergeRecords != null) {
                        Record[] records = mergeRecords.clone();
                        long startTime = System.currentTimeMillis(); // store the current time (Before Sorting)
                        sortingAlgo.mergeSort(records, 0, records.length - 1);
                        long endTime = System.currentTimeMillis(); // store the current time (After Sorting)
                        long executionTime = endTime - startTime;
                        System.out.println("Merge Sort:");
                        printRecords(records);
                        System.out.println();
                        System.out.println("Execution Time: " +executionTime+ " millisecond/s");
                        System.out.println();
                        Record[] recordsCounter = mergeRecords.clone();
                        long mrgCount = counter.mergeSort(recordsCounter, 0, recordsCounter.length - 1);
                        System.out.println("Empirical Frequency Count: " +mrgCount);
                        System.out.println();
                        boolean isSorted = verifySorting(records);
                        if(isSorted)
                        {
                            System.out.println("Sorting Successful! Results: " + true);
                        }
                        else
                        {
                            System.out.println("Sorting unsuccessful... Results: " + false);
                        }
                        System.out.println();
                        System.out.println();
                    }
                    break;
                }
                case 4: { // Quick sort
                    if (quickRecords != null) {
                        Record[] records = quickRecords.clone();
                        long startTime = System.currentTimeMillis(); // store the current time (Before Sorting)
                        sortingAlgo.quickSort(records, 0, records.length - 1);
                        long endTime = System.currentTimeMillis(); // store the current time (After Sorting)
                        long executionTime = endTime - startTime;
                        System.out.println("Quick Sort:");
                        printRecords(records);
                        System.out.println();
                        System.out.println("Execution Time: " +executionTime+ " millisecond/s");
                        System.out.println();
                        Record[] recordsCounter = quickRecords.clone();
                        long qckCount = counter.quickSort(recordsCounter, 0, recordsCounter.length - 1);
                        System.out.println("Empirical Frequency Count: " +qckCount);
                        System.out.println();
                        boolean isSorted = verifySorting(records);
                        if(isSorted)
                        {
                            System.out.println("Sorting Successful! Results: " + true);
                        }
                        else
                        {
                            System.out.println("Sorting unsuccessful... Results: " + false);
                        }
                        System.out.println();
                        System.out.println();
                    }
                    break;
                }
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

        scanner.close();
    }

    private static void printRecords(Record[] records) { // print the list
        for (Record record : records) {
            System.out.println("ID: " + record.getIdNumber() + ", Name: " + record.getName());
        }
    }

    private static boolean verifySorting(Record[] records) { // check if list is correctly ordered
        for (int i = 1; i < records.length; i++) {
            if (records[i].getIdNumber() < records[i - 1].getIdNumber()) {
                return false;
            }
        }
        return true;
    }
}


