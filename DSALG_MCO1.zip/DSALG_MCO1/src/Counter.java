import java.util.Stack;

public class Counter {
        private long swap(Record[] arr, int index1, int index2) {
            long freqCount = 0;
            Record temp = arr[index1]; freqCount++;
            arr[index1] = arr[index2]; freqCount++;
            arr[index2] = temp; freqCount++;
            return freqCount;
        }

        public long insertionSort(Record[] arr, int n) {

            int i, j, key;
            long freqCount=0;

            freqCount++; // i = 1
            for (i = 1; i < n; i++) { freqCount++; // i < n
                key = arr[i].getIdNumber(); freqCount++;
                j = i - 1; freqCount++;

                while (j >= 0 && arr[j].getIdNumber() > key) { freqCount++; // while loop cond. count
                    freqCount += swap(arr, j, j + 1);
                    j--; freqCount++;
                }
                freqCount++; // i++
            }
            return freqCount;
        }

        public long selectionSort(Record[] arr, int n) {
            int i, j, min;
            long freqCount = 0;
            freqCount++; // i = 0
            for (i = 0; i < n - 1; i++) { freqCount++; // i < n - 1
                min = i; freqCount++;
                freqCount++; // j = i + 1
                for (j = i + 1; j < n; j++) { freqCount++; // j < n
                    if (arr[j].getIdNumber() < arr[min].getIdNumber()) { freqCount++; // if count
                        min = j; freqCount++;
                    }
                    freqCount++; // j++
                }
                freqCount += swap(arr, i, min);
                freqCount++; // i++
            }
            return freqCount;
        }

        public long merge(Record[] arr, int p, int q, int r) {
            long freqCount = 0;
            int n1 = q - p + 1; freqCount++;
            int n2 = r - q; freqCount++;

            Record[] left = new Record[n1]; freqCount++;
            Record[] right = new Record[n2]; freqCount++;

            freqCount++; // i = 0
            for (int i = 0; i < n1; i++) { freqCount++; // i < n1
                left[i] = arr[p + i]; freqCount++;
                freqCount++; // i++
            }
            freqCount++; // j = 0
            for (int j = 0; j < n2; j++) { freqCount++; // i < n2
                right[j] = arr[q + 1 + j]; freqCount++;
                freqCount++; // j++
            }

            int i = 0; freqCount++;
            int j = 0; freqCount++;
            int k = p; freqCount++;

            while (i < n1 && j < n2) { freqCount++; // while cond. counter

                if (left[i].getIdNumber() <= right[j].getIdNumber()) { freqCount++; // if cond. counter
                    arr[k] = left[i]; freqCount++;
                    i++; freqCount++;
                } else {
                    arr[k] = right[j]; freqCount++;
                    j++; freqCount++;
                }
                k++; freqCount++;
            }
            while (i < n1) { freqCount++; // if cond. counter
                arr[k] = left[i]; freqCount++;
                i++; freqCount++;
                k++; freqCount++;
            }
            while (j < n2) { freqCount++; // if cond. counter
                arr[k] = right[j]; freqCount++;
                j++; freqCount++;
                k++; freqCount++;
            }
            return freqCount;
        }

        public long mergeSort(Record[] arr, int p, int r) {
            long freqCount = 0;
            if (p < r) { freqCount++; // if count

                int q = p + (r - p) / 2;  freqCount++;
                freqCount += mergeSort(arr, p, q);

                freqCount += mergeSort(arr, q + 1, r);

                freqCount += merge(arr, p, q, r);
            }
            return freqCount;
        }

        private class PartitionResult { // To be able to return both the Pivot Index and Frequency Count from partition
            private int index;
            private long freqCount;

            public PartitionResult(int index, long freqCount) {
                this.index = index;
                this.freqCount = freqCount;
            }

            public int getIndex() {
                return index;
            }

            public long getFreqCount() {
                return freqCount;
            }
        }

        private PartitionResult partition(Record[] arr, int low, int high) {
            long freqCount = 0;
            int pivot = arr[high].getIdNumber(); freqCount++;

            int i = (low - 1); freqCount++;

            freqCount++; // j = low
            for (int j = low; j <= high - 1; j++) { freqCount++; // j <= high

                if (arr[j].getIdNumber() < pivot) { freqCount++; // if cond. counter
                    i++; freqCount++;
                    freqCount += swap(arr, i, j);

                }
            }
            freqCount += swap(arr, i + 1, high);
            return new PartitionResult(i + 1, freqCount);
        }

        public long quickSort(Record[] arr, int low, int high) {
            long freqCount=0;
            Stack<Integer> stack = new Stack<>(); freqCount++;
            stack.push(low); freqCount++;
            stack.push(high); freqCount++;

            while (!stack.isEmpty()) { freqCount++; // while cond. counter
                high = stack.pop(); freqCount++;
                low = stack.pop(); freqCount++;

                int pivotIndex = partition(arr, low, high).getIndex(); // get the Pivot Index
                freqCount += partition(arr, low, high).getFreqCount(); // get the Frequency Count of the Partition method

                if (pivotIndex - 1 > low) { freqCount++; // if cond. counter
                    stack.push(low); freqCount++;
                    stack.push(pivotIndex - 1); freqCount++;
                }

                if (pivotIndex + 1 < high) { freqCount++; // if cond. counter
                    stack.push(pivotIndex + 1); freqCount++;
                    stack.push(high); freqCount++;

                }

            }
            return freqCount;
        }
    }

