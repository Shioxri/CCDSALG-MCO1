/* This file contains implementations of sorting algorithms.
 * You are NOT allowed to modify any of the given method headers.
 */

import java.util.Stack;

public class SortingAlgorithms {

    private void swap(Record[] arr, int index1, int index2) {
        Record temp = arr[index1];
        arr[index1] = arr[index2];
        arr[index2] = temp;
    }

    public void insertionSort(Record[] arr, int n) {
        int i, j, key;

        for (i = 1; i < n; i++) {
            key = arr[i].getIdNumber();
            j = i - 1;

            while (j >= 0 && arr[j].getIdNumber() > key) {
                swap(arr, j, j + 1);
                j--;
            }
        }
    }

    public void selectionSort(Record[] arr, int n) {
        int i, j, min;
        for (i = 0; i < n - 1; i++) {
            min = i;
            for (j = i + 1; j < n; j++) {
                if (arr[j].getIdNumber() < arr[min].getIdNumber()) {
                    min = j;
                }
            }
            swap(arr, i, min);
        }

    }

    public void merge(Record[] arr, int p, int q, int r) {
        int n1 = q - p + 1;
        int n2 = r - q;

        Record[] left = new Record[n1];
        Record[] right = new Record[n2];

        for (int i = 0; i < n1; i++)
            left[i] = arr[p + i];
        for (int j = 0; j < n2; j++)
            right[j] = arr[q + 1 + j];

        int i = 0;
        int j = 0;
        int k = p;

        while (i < n1 && j < n2) {
            if (left[i].getIdNumber() <= right[j].getIdNumber()) {
                arr[k] = left[i];
                i++;
            } else {
                arr[k] = right[j];
                j++;
            }
            k++;
        }
        while (i < n1) {
            arr[k] = left[i];
            i++;
            k++;
        }
        while (j < n2) {
            arr[k] = right[j];
            j++;
            k++;
        }
    }

    public void mergeSort(Record[] arr, int p, int r) {
        if (p < r) {
            int q = p + (r - p) / 2;
            mergeSort(arr, p, q);
            mergeSort(arr, q + 1, r);
            merge(arr, p, q, r);
        }
    }

    private int partition(Record[] arr, int low, int high) {
        int pivot = arr[high].getIdNumber();

        int i = (low - 1);

        for (int j = low; j <= high - 1; j++) {

            if (arr[j].getIdNumber() < pivot) {
                i++;
                swap(arr, i, j);
            }
        }
        swap(arr, i + 1, high);
        return (i + 1);
    }

    public void quickSort(Record[] arr, int low, int high) {
        Stack<Integer> stack = new Stack<>();
        stack.push(low);
        stack.push(high);

        while (!stack.isEmpty()) {
            high = stack.pop();
            low = stack.pop();

            int pivotIndex = partition(arr, low, high);

            if (pivotIndex - 1 > low) {
                stack.push(low);
                stack.push(pivotIndex - 1);
            }

            if (pivotIndex + 1 < high) {
                stack.push(pivotIndex + 1);
                stack.push(high);

            }

        }
    }
}
